/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// Define the GPIO port and pin for the DHT11 sensor
#define DHT11_PORT GPIOA
#define DHT11_PIN GPIO_PIN_0
#define DHT11_TIMEOUT 20000
#define DHT11_ERROR -1
#define DHT11_OK 1

void delay_us (uint16_t us)
{
	__HAL_TIM_SET_COUNTER(&htim1,0);  // set the counter value a 0
	while (__HAL_TIM_GET_COUNTER(&htim1) < us);  // wait for the counter to reach the us input in the parameter
}

void resetTIM1(){
	__HAL_TIM_SET_COUNTER(&htim1,0);  // set the counter value a 0
}

uint16_t getTIM1()
{
	return __HAL_TIM_GET_COUNTER(&htim1);
}






int dht11_request() {
    	HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_RESET);
        HAL_Delay(20); // correct: 18 ms
        HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_SET);

        // Wait for the DHT11 sensor to respond
        resetTIM1();
        while (HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN))
        {
            if (getTIM1() > 100) return DHT11_TIMEOUT;
        }
        resetTIM1();
        while (!HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN))
        {
        	if (getTIM1() > 100) return DHT11_TIMEOUT;
        }
        delay_us(40);
        return 0;
}

void dht11_read_byte(uint8_t *byte) {

	uint8_t j;
	for (j=0;j<8;j++)
	{
		while (!(HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN)));   // wait for the pin to go high
		delay_us(40);   // wait for 40 us
		if (!(HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN)))   // if the pin is low
		{
			*byte&= ~(1<<(7-j));   // write 0
		}
		else *byte|= (1<<(7-j));  // if the pin is high, write 1
		while ((HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN)));  // wait for the pin to go low

	}
}

int dht11_read_data(float* temperature, float* humidity) {
    uint8_t crc = 0;
    uint8_t data[4] = {0, 0, 0, 0};
    resetTIM1();
    if (dht11_request() == DHT11_TIMEOUT){
    	return DHT11_TIMEOUT;
    }

    // wait for the response

    // read the data
    for (int i = 0; i < 4; i++) {
         dht11_read_byte(&data[i]);
    }
    crc = data[0] + data[1] + data[2] + data[3];
    // check the checksum
//    if (data[4] == crc) {
        *humidity = data[0] + data[1] * 0.1f;
        *temperature = data[2] + (data[3] & 0x0f) * 0.1;
        return DHT11_OK;
//    } else {
//        *humidity = 0;
//        *temperature = 0;
//    }
}

void DHT11_interface(float* temperature, float* humidity){

	      // Read data from the DHT11 sensor
		  int read = dht11_read_data(temperature, humidity);
	      char buffer[60];
	      if (read == DHT11_OK) {
	   	   if (*temperature>0 && *humidity < 2147483600){
	              sprintf(buffer, "Temperature: %4.1f, Humidity: %4.1f\r\n", *temperature+8, *humidity*100/255);
//	              sprintf(buffer, "Temperature: %d, Humidity: %d\r\n", *temperature_int, *humidity_int);
	              HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 10);
	   	   }
	       else{
	     	  sprintf(buffer, "OUT OF RANGE\r\n");
	     	  HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 10);
	       }
	      }
	      else if (read == DHT11_ERROR){
	    	  sprintf(buffer, "DHT11_ERROR\r\n");
	    	  HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 10);
	      }
	      else if (read == DHT11_TIMEOUT){
	    	  sprintf(buffer, "DHT11_TIMEOUT\r\n");
	    	  HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 10);
	      }
	      else{
	    	  sprintf(buffer, "DUPA\r\n");
	    	  HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 10);
	      }


	      // Wait for some time before reading the sensor again
	          HAL_Delay(1000);
}

void mode_handle(float* temperature, float* humidity, int* mode)
{
    char buffer[60];
    if (*mode == 1){
    	sprintf(buffer, "Manual mode\r\n");
    	HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 10);
    }
    else{
    	sprintf(buffer, "Auto mode\r\n");
    	HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 10);
    }
}

void correct_data(float* temperature, float* humidity){
	*temperature+=8;
	*humidity=*humidity*100/255;
}

void simulate_data(float* temperature, float* humidity){
	if(*temperature>17 && *temperature<36)
		*temperature+=2;
	else
		*temperature=18;
	char buffer[100];
    sprintf(buffer, "Temperature: %4.1f, Humidity: %4.1f\r\n", *temperature+8, *humidity*100/255);
    HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 10);

//	*humidity=*humidity*100/255;
}

void generate_PWM(float* temperature, float* humidity, float *PWM) {

    char buffer[100];
  // Define the maximum and minimum duty cycle values
  uint32_t maxDutyCycle = htim2.Init.Period; // 100% duty cycle
  uint32_t minDutyCycle = 0; // 0% duty cycle
  uint32_t dutyCycleTemp;
  uint32_t dutyCycleHumid;
  uint32_t dutyCycle;

  // Define the target temperatures for the transition
  float startTemperature = 18.0;
  float endTemperature = 29.5;
  float startHumidity = 70.0;
  float endHumidity = 90.0;

  float temperatureRange;
  float temperatureRangePercentage;
  float humidityRange;
  float humidityRangePercentage;
  // Check if the temperature is within the range to trigger the transition
  if (*temperature >= startTemperature && *temperature <= endTemperature) {
    // Calculate the current temperature range as a percentage
    temperatureRange = *temperature - startTemperature;
    temperatureRangePercentage = temperatureRange / (endTemperature - startTemperature);
//	sprintf(buffer, "dutyCycleTemp=%d\r\n",dutyCycleTemp);
//	HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 10);


  }
  if (*humidity >= startHumidity && *humidity <= endHumidity) {
    // Calculate the current temperature range as a percentage
	humidityRange = *humidity - startHumidity;
    humidityRangePercentage = humidityRange / (endHumidity - startHumidity);
//	sprintf(buffer, "dutyCycleHumid=%d\r\n",dutyCycleHumid);
//	HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 10);
  }



  // Update the duty cycle value
  if (temperatureRangePercentage>humidityRangePercentage){
	  dutyCycle = minDutyCycle + (temperatureRangePercentage * (maxDutyCycle - minDutyCycle));
	  *PWM = temperatureRangePercentage;
  }
  else{
	  dutyCycle = minDutyCycle + (humidityRangePercentage * (maxDutyCycle - minDutyCycle));
  	  *PWM = humidityRangePercentage;
  }
  htim2.Instance->CCR1 = dutyCycle;


	sprintf(buffer, "PWM=%4.1f\r\n",*PWM);
	HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 10);
}






/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */

  // Start the PWM output on TIM2 Channel 1
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);


//  uint8_t Test[] = "Hello World !!!\r\n"; //Data to send
//  HAL_UART_Transmit(&huart2,Test,sizeof(Test),10);// Sending in normal mode
  HAL_TIM_Base_Start(&htim1);
//  ESP_Init("Wiezienna_30_22","Ja_to_nie_doktor_Dolittle");
  ESP_Init("accespoint","12345678");


  int mode = 0; //1 for manual, 0 for automatic
  float PWM = 0;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  float temperature = 21, humidity = 50;
  while (1)
  {

	  Server_Start(&temperature, &humidity, &mode, &PWM);
	  DHT11_interface(&temperature, &humidity);
	  correct_data(&temperature, &humidity);
//	  simulate_data(&temperature, &humidity);
	  if (mode == 1){
		  PWM = 1;
		  htim2.Instance->CCR1 = htim2.Init.Period;
	  }
	  else
		  generate_PWM(&temperature, &humidity, &PWM);
//	  HAL_Delay(2000);


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 40;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 80;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 0xffff-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 65535;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(DHT11_GPIO_Port, DHT11_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);

  /*Configure GPIO pin : DHT11_Pin */
  GPIO_InitStruct.Pin = DHT11_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(DHT11_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PB2 */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
